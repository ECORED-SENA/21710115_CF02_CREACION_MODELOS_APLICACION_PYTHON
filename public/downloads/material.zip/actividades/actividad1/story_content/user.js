function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5nyDLf1zdXt":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

