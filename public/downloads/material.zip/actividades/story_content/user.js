function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6RKVuWYM22r":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

